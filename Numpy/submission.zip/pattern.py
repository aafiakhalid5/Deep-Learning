import numpy as np
import matplotlib.pyplot as plt


class Checker:
    def __init__(self, resolution, tile_size):
        if resolution % (2 * tile_size) != 0:
            raise ValueError(
                "Resolution should divide evenly into 2 * tile size")  # probably should handle this more gracefully
        self.resolution = resolution
        self.tile_size = tile_size
        self.output = None  # placeholder for the generated image

    def draw(self):
        base_tile = np.array([[0, 1], [1, 0]])  # classic checker tile
        num_tiles = self.resolution // (2 * self.tile_size)
        checker_pattern = np.tile(base_tile, (num_tiles, num_tiles))
        self.output = np.kron(checker_pattern, np.ones((self.tile_size, self.tile_size)))

        return self.output.copy()  # safer to return a copy

    def show(self):
        if self.output is not None:
            plt.imshow(self.output, cmap='gray')
            plt.title("Checker Pattern")
            plt.axis('off')  # cleaner without ticks
            plt.show()


# Circle class to generate a filled circle in a 2D numpy array
class Circle:
    def __init__(self, resolution, radius, position):
        self.resolution = resolution
        self.radius = radius
        self.position = position
        self.output = None  # again, for storing the image

    def draw(self):
        # Maybe overkill with meshgrid, but it's readable
        y = np.arange(self.resolution)
        x = np.arange(self.resolution)
        xx, yy = np.meshgrid(x, y)

        # Extract center coordinates
        cx, cy = self.position

        dist2 = (xx - cx) ** 2 + (yy - cy) ** 2

        # Simple threshold for circle
        self.output = (dist2 <= self.radius ** 2)

        return self.output.copy()

    def show(self):
        if self.output is not None:
            plt.imshow(self.output, cmap='gray')
            plt.title("Circle Pattern")
            plt.axis('off')
            plt.show()


# Spectrum class – makes a basic RGB gradient field
class Spectrum:
    def __init__(self, resolution):
        self.resolution = resolution
        self.output = None

    def draw(self):
        # Making two gradients from 0 to 1
        horiz = np.linspace(0, 1, self.resolution)
        vert = np.linspace(0, 1, self.resolution)

        red, green = np.meshgrid(horiz, vert)
        blue = 1 - red  # kinda just an aesthetic choice

        # Merge the channels into an RGB image
        self.output = np.stack((red, green, blue), axis=2)

        return self.output.copy()  # maybe unnecessary but safe

    def show(self):
        if self.output is not None:
            plt.imshow(self.output)
            plt.axis('off')  # same here, no ticks
            plt.show()
